#include "helpers.h"
#include <math.h>
#include <stdlib.h>
// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for(int i=0;i<height;i++)
    {
        for(int j=0;j<width;j++)
        {
            BYTE a =image[i][j].rgbtRed;
            BYTE b =image[i][j].rgbtGreen;
            BYTE c =image[i][j].rgbtBlue;
            int average = round((a+b+c)/3);
            BYTE*a1 =&image[i][j].rgbtRed;
            BYTE*b1 =&image[i][j].rgbtGreen;
            BYTE*c1 =&image[i][j].rgbtBlue;
            *a1=average;
            *b1=average;
            *c1=average;


        }
    }
    return;
}

// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
     for(int i=0;i<height;i++)
    {
        for(int j=0;j<width;j++)
        {
            BYTE a =image[i][j].rgbtRed;
            BYTE b =image[i][j].rgbtGreen;
            BYTE c =image[i][j].rgbtBlue;
            int newa=round(0.393*a + 0.769*b + 0.189*c);
            int newb=round(0.349*a + 0.686*b + 0.168*c);
            int newc=round(0.272*a + 0.534*b + 0.131*c);
            if(newa > 255)
            {
                newa = 255;
            }
            if(newb > 255)
            {
                newb = 255;
            }
            if(newc > 255)
            {
                newc = 255;
            }
            BYTE*a1 =&image[i][j].rgbtRed;
            BYTE*b1 =&image[i][j].rgbtGreen;
            BYTE*c1 =&image[i][j].rgbtBlue;
            *a1=newa;
            *b1=newb;
            *c1=newc;
        }
    }

    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
     for(int i=0;i<height;i++)
    {
        for(int j=0;j<width/2;j++)
        {
            RGBTRIPLE*newimage =&image[i][j];
            RGBTRIPLE newimage2 =image[i][j];

            RGBTRIPLE*newimage1 =&image[i][abs(width-j)];
            *newimage=image[i][abs(width-j)];
            *newimage1=newimage2;
        }
    }

    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
            BYTE*a9 =&image[0][0].rgbtRed;
            BYTE*b9 =&image[0][0].rgbtGreen;
            BYTE*c9 =&image[0][0].rgbtBlue;
           BYTE a=round((image[0][0].rgbtRed + image[0][1].rgbtRed + image[1][0].rgbtRed + image[1][1].rgbtRed)/4);
           BYTE b=round((image[0][0].rgbtGreen + image[0][1].rgbtGreen + image[1][0].rgbtGreen + image[1][1].rgbtGreen)/4);
           BYTE c =round((image[0][0].rgbtBlue + image[0][1].rgbtBlue + image[1][0].rgbtBlue + image[1][1].rgbtBlue)/4);
            BYTE*aa =&image[0][width].rgbtRed;
            BYTE*bb =&image[0][width].rgbtGreen;
            BYTE*cc =&image[0][width].rgbtBlue;
           BYTE a1=round((image[0][width].rgbtRed + image[0][width - 1].rgbtRed + image[1][width].rgbtRed + image[1][width - 1].rgbtRed)/4);
           BYTE b1=round((image[0][width].rgbtGreen + image[0][width - 1].rgbtGreen + image[1][width].rgbtGreen + image[1][width - 1].rgbtGreen)/4);
           BYTE c1 =round((image[0][width].rgbtBlue + image[0][width - 1].rgbtBlue + image[1][width].rgbtBlue + image[1][width - 1].rgbtBlue)/4);
           BYTE*aaa =&image[height][width].rgbtRed;
            BYTE*bbb =&image[height][width].rgbtGreen;
            BYTE*ccc =&image[height][width].rgbtBlue;
           BYTE a2=round((image[height][width].rgbtRed + image[height][width - 1].rgbtRed + image[height - 1][width].rgbtRed + image[height - 1][width - 1].rgbtRed)/4);
           BYTE b2=round((image[height][width].rgbtGreen + image[height][width - 1].rgbtGreen + image[height - 1][width].rgbtGreen + image[height - 1][width - 1].rgbtGreen)/4);
           BYTE c2 =round((image[height][width].rgbtBlue + image[height][width - 1].rgbtBlue + image[height - 1][width].rgbtBlue + image[height - 1][width - 1].rgbtBlue)/4);
           BYTE*aaaa =&image[height][0].rgbtRed;
            BYTE*bbbb =&image[height][0].rgbtGreen;
            BYTE*cccc =&image[height][0].rgbtBlue;
           BYTE a3=round((image[height][0].rgbtRed + image[height][1].rgbtRed + image[height - 1][0].rgbtRed + image[height - 1][1].rgbtRed)/4);
           BYTE b3=round((image[height][0].rgbtGreen + image[height][1].rgbtGreen + image[height - 1][0].rgbtGreen + image[height - 1][1].rgbtGreen)/4);
           BYTE c3 =round((image[height][0].rgbtBlue + image[height][1].rgbtBlue + image[height - 1][0].rgbtBlue + image[height - 1][1].rgbtBlue)/4);
           BYTE*a10[height - 1];
           BYTE*b10[height - 1];
           BYTE*c10[height - 1];
           BYTE a4[height - 1];
           BYTE b4[height - 1];
           BYTE c4[height - 1];
           for(int i=1; i<height; i++)
            {
                    a10[i - 1] =&image[i][0].rgbtRed;
                    b10[i - 1] =&image[i][0].rgbtGreen;
                    c10[i - 1] =&image[i][0].rgbtBlue;
                    a4[i - 1]=round((image[i][0].rgbtRed + image[i][1].rgbtRed + image[i - 1][0].rgbtRed + image[i - 1][1].rgbtRed + image[i + 1][0].rgbtRed + image[i + 1][1].rgbtRed)/6);
                    b4[i - 1]=round((image[i][0].rgbtGreen + image[i][1].rgbtGreen + image[i - 1][0].rgbtGreen + image[i - 1][1].rgbtGreen + image[i + 1][0].rgbtGreen + image[i + 1][1].rgbtGreen)/6);
                    c4[i - 1] =round((image[i][0].rgbtBlue + image[i][1].rgbtBlue + image[i - 1][0].rgbtBlue + image[i - 1][1].rgbtBlue + image[i + 1][0].rgbtBlue + image[i + 1][1].rgbtBlue)/6);
            }
           BYTE*aa1[height - 1];
           BYTE*bb1[height - 1];
           BYTE*cc1[height - 1];
           BYTE a5[height - 1];
           BYTE b5[height - 1];
           BYTE c5[height - 1];


           for(int j=1; j<height; j++)
           {
                aa1[j - 1] =&image[j][width].rgbtRed;
                bb1[j - 1] =&image[j][width].rgbtGreen;
                cc1[j - 1] =&image[j][width].rgbtBlue;
                 a5[j - 1]=round((image[j][width].rgbtRed + image[j][width - 1].rgbtRed + image[j - 1][width].rgbtRed + image[j - 1][width - 1].rgbtRed + image[j + 1][width].rgbtRed + image[j + 1][width - 1].rgbtRed)/6);
                 b5[j - 1]=round((image[j][width].rgbtGreen + image[j][width - 1].rgbtGreen + image[j - 1][width].rgbtGreen + image[j - 1][width - 1].rgbtGreen + image[j + 1][width].rgbtGreen + image[j + 1][width - 1].rgbtGreen)/6);
                 c5[j - 1] =round((image[j][width].rgbtBlue + image[j][width - 1].rgbtBlue + image[j - 1][width].rgbtBlue + image[j - 1][width - 1].rgbtBlue + image[j + 1][width].rgbtBlue + image[j + 1][width - 1].rgbtBlue)/6);


           }
           BYTE*aaa1[width - 1];
           BYTE*bbb1[width - 1];
           BYTE*ccc1[width - 1];
           BYTE a6[width - 1];
           BYTE b6[width - 1];
           BYTE c6[width - 1];
           for(int k=1; k<width; k++)
            {
                      aaa1[k - 1] =&image[0][k].rgbtRed;
                      bbb1[k - 1] =&image[0][k].rgbtGreen;
                      ccc1[k - 1] =&image[0][k].rgbtBlue;
                      a6[k - 1]=round((image[0][k].rgbtRed + image[1][k].rgbtRed + image[0][k - 1].rgbtRed + image[1][k - 1].rgbtRed + image[0][k + 1].rgbtRed + image[1][k + 1].rgbtRed)/6);
                      b6[k - 1]=round((image[0][k].rgbtGreen + image[1][k].rgbtGreen + image[0][k - 1].rgbtGreen + image[1][k - 1].rgbtGreen + image[0][k + 1].rgbtGreen + image[1][k + 1].rgbtGreen)/6);
                      c6[k - 1] =round((image[0][k].rgbtBlue + image[1][k].rgbtBlue + image[0][k - 1].rgbtBlue + image[1][k - 1].rgbtBlue + image[0][k + 1].rgbtBlue + image[1][k + 1].rgbtBlue)/6);
            }
            BYTE*aaaa1[width - 1];
           BYTE*bbbb1[width - 1];
           BYTE*cccc1[width - 1];
           BYTE a7[width - 1];
           BYTE b7[width - 1];
           BYTE c7[width - 1];
            for(int l=1; l<width; l++)
            {
                      aaaa1[l - 1] =&image[height][l].rgbtRed;
                      bbbb1[l - 1] =&image[height][l].rgbtGreen;
                      cccc1[l - 1] =&image[height][l].rgbtBlue;
                      a7[l - 1]=round((image[height][l].rgbtRed + image[height - 1][l].rgbtRed + image[height][l - 1].rgbtRed + image[height - 1][l - 1].rgbtRed + image[height][l + 1].rgbtRed + image[height - 1][l + 1].rgbtRed)/6);
                      b7[l - 1]=round((image[height][l].rgbtGreen + image[height - 1][l].rgbtGreen + image[height][l - 1].rgbtGreen + image[height - 1][l - 1].rgbtGreen + image[height][l + 1].rgbtGreen + image[height - 1][l + 1].rgbtGreen)/6);
                      c7[l - 1] =round((image[height][l].rgbtBlue + image[height - 1][l].rgbtBlue + image[height][l - 1].rgbtBlue + image[height - 1][l - 1].rgbtBlue + image[height][l + 1].rgbtBlue + image[height - 1][l + 1].rgbtBlue)/6);
            }
            BYTE*a20[height - 1][width - 1];
           BYTE*b20[height - 1][width - 1];
           BYTE*c20[height - 1][width - 1];
           BYTE a8[height - 1][width - 1];
           BYTE b8[height - 1][width - 1];
           BYTE c8[height - 1][width - 1];
            for(int m=1; m<height; m++)
            {
                for(int n=1; n<width; n++)
                {
                      a20[m - 1][n - 1] =&image[m][n].rgbtRed;
                      b20[m - 1][n - 1] =&image[m][n].rgbtGreen;
                      c20[m - 1][n - 1] =&image[m][n].rgbtBlue;
                      a8[m - 1][n - 1]=round((image[m][n].rgbtRed + image[m ][n + 1].rgbtRed + image[m][n - 1].rgbtRed + image[m - 1][n - 1].rgbtRed + image[m - 1][n].rgbtRed + image[m - 1][n + 1].rgbtRed + image[m + 1][n + 1].rgbtRed + image[m + 1][n - 1].rgbtRed + image[m + 1][n].rgbtRed)/9);
                      b8[m - 1][n - 1]=round((image[m][n].rgbtGreen + image[m][n + 1].rgbtGreen + image[m][n - 1].rgbtGreen + image[m - 1][n - 1].rgbtGreen + image[m - 1][n].rgbtGreen + image[m - 1][n + 1].rgbtGreen + image[m + 1][n + 1].rgbtGreen + image[m + 1][n - 1].rgbtGreen + image[m + 1][n].rgbtGreen)/9);
                      c8[m - 1][n - 1] =round((image[m][n].rgbtBlue + image[m][n + 1].rgbtBlue + image[m][n - 1].rgbtBlue + image[m - 1][n - 1].rgbtBlue + image[m - 1][n].rgbtBlue + image[m - 1][n + 1].rgbtBlue + image[m + 1][n + 1].rgbtBlue + image[m + 1][n - 1].rgbtBlue + image[m + 1][n].rgbtBlue)/9);

                }
            }
            *a9 = a;
            *b9 = b;
            *c9 = c;
            *aa = a1;
            *bb = b1;
            *cc = c1;
            *aaa = a2;
            *bbb = b2;
            *ccc = c2;
            *aaaa = a3;
            *bbbb = b3;
            *cccc = c3;
            for(int o = 0 ; o<height - 1; o++)
            {
                *a10[o] = a4[o];
                *b10[o] = b4[o];
                *c10[o] = c4[o];
            }
            for(int p =0; p<height - 1; p++)
            {
                *aa1[p] = a5[p];
                *bb1[p] = b5[p];
                *cc1[p] = c5[p];
            }
            for(int q = 0; q<width - 1; q++)
            {
                *aaa1[q] = a6[q];
                *bbb1[q] = b6[q];
                *ccc1[q] = c6[q];
            }
            for(int r =0; r<width - 1; r++)
            {
                *aaaa1[r] = a7[r];
                *bbbb1[r] = b7[r];
                *cccc1[r] = c7[r];
            }
            for(int s=0; s<height - 1; s++)
            {
                for(int t=0; t<width - 1; t++)
                {
                    *a20[s][t] = a8[s][t];
                    *b20[s][t] = b8[s][t];
                    *c20[s][t] = c8[s][t];
                }
            }
                return;
}


















































